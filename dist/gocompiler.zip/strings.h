#ifndef COMPILERS_STRINGS_H
#define COMPILERS_STRINGS_H

extern char * trim_value(char * original_value);
extern char * to_lower(char * src_string);

#endif //COMPILERS_STRINGS_H
