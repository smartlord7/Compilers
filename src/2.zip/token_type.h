/*
	Compiladores 2021/ 2022, LEI, UC
	
	Meta 2
	
	João Filipe Guiomar Artur, 2019217853
	Sancho Amaral Simões, 2019217590

*/

#ifndef GOCOMPILER_L_TOKEN_TYPE_H
#define GOCOMPILER_L_TOKEN_TYPE_H

typedef enum {
    NEW_LINE_,
    SEMICOLON_,
    COMMA_,
    BLANK_ID_,
    ASSIGN_,
    STAR_,
    DIV_,
    MINUS_,
    PLUS_,
    EQ_,
    GE_,
    GT_,
    LBRACE_,
    LE_,
    LPAR_,
    LSQ_,
    LT_,
    MOD_,
    NE_,
    NOT_,
    AND_,
    OR_,
    RBRACE_,
    RPAR_,
    RSQ_,
    PACKAGE_,
    RETURN_,
    ELSE_,
    FOR_,
    IF_,
    VAR_,
    INT_,
    FLOAT32_,
    BOOL_,
    STRING_,
    PRINT_,
    PARSE_INT_,
    FUNC_,
    CMDARGS_,
    RESERVED_,
    ID_,
    INT_LIT_,
    REAL_LIT_,
    STRING_LIT_,
    OTHER_,
    STRING_START_,
    STRING_END_,
    LINE_COMMENT_START_,
    GENERAL_COMMENT_START_,
    GENERAL_COMMENT_END_,
    IGNORE_,
    IGNORE_NEW_LINE_,
} token_type;

extern char * token_types[];

#endif //GOCOMPILER_L_TOKEN_TYPE_H
