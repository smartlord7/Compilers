/*
	Compiladores 2021/ 2022, LEI, UC
	
	Meta 1
	
	João Filipe Guiomar Artur, 2019217853
	Sancho Amaral Simões, 2019217590

*/

const char * token_types[] = {
        "NEW_LINE",
        "SEMICOLON",
        "COMMA",
        "BLANKID",
        "ASSIGN",
        "STAR",
        "DIV",
        "MINUS",
        "PLUS",
        "EQ",
        "GE",
        "GT",
        "LBRACE",
        "LE",
        "LPAR",
        "LSQ",
        "LT",
        "MOD",
        "NE",
        "NOT",
        "AND",
        "OR",
        "RBRACE",
        "RPAR",
        "RSQ",
        "PACKAGE",
        "RETURN",
        "ELSE",
        "FOR",
        "IF",
        "VAR",
        "INT",
        "FLOAT32",
        "BOOL",
        "STRING",
        "PRINT",
        "PARSEINT",
        "FUNC",
        "CMDARGS",
        "RESERVED",
        "ID",
        "INTLIT",
        "REALLIT",
        "STRLIT",
        "OTHER",
        "STRING_START",
        "STRING_END",
        "LINE_COMMENT_START",
        "GENERAL_COMMENT_START",
        "GENERAL_COMMENT_END",
        "IGNORE",
        "IGNORE_NEW_LINE",
};
