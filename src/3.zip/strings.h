/*
	Compiladores 2021/ 2022, LEI, UC
	
	Meta 3
	
	João Filipe Guiomar Artur, 2019217853
	Sancho Amaral Simões, 2019217590

*/

#ifndef COMPILERS_STRINGS_H
#define COMPILERS_STRINGS_H

extern char * trim_value(char * original_value);
extern char * to_lower(char * src_string);

#endif //COMPILERS_STRINGS_H
